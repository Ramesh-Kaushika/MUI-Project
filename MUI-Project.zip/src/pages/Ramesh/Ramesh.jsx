export default function Ramesh() {

    return(
        <>
        <h1>Ramesh Private Page </h1>
        </>
    )
}