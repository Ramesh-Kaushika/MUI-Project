import Button from '@mui/material/Button';

export default function Button1({name, onclick}) {
    return (
        /* <Button variant="contained" color="success" onClick={()=>onclick()}>
             {name}
         </Button>*/
        <div>
            <h1>Dashboard</h1>
        </div>


    )
}